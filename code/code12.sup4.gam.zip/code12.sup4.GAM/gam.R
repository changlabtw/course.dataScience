library(ggplot2)

# prepare data
set.seed(602957)
x <- rnorm(1000)
noise <- rnorm(1000, sd=1.5)
y <- 3*sin(2*x) + cos(0.75*x) - 1.5*(x^2 ) + noise
select <- runif(1000)
frame <- data.frame(y=y, x = x)
train <- frame[select > 0.1,]
test <-frame[select <= 0.1,]

# Linear regression applied to our artificial example
lin.model <- lm(y ~ x, data=train)
summary(lin.model)
#calculate the root mean squared error (rmse)
resid.lin <- train$y-predict(lin.model)
sqrt(mean(resid.lin^2))

# GAM applied to our artificial example
library(mgcv)
glin.model <- gam(y~s(x), data=train)
# y ~ x => the same with lm
glin.model$converged
# The converged parameter tells you if the algorithm converged. You should only trust the output if this is TRUE.
summary(glin.model)
# The smooth terms are the nonlinear terms.
# the effective degrees of freedom (edf) used up to build each smooth term. An edf near 1 indicates that the variable has an approximately linear relationship to the output
# R-sq (adj) =  adjusted R-squared.
# Deviance explained  = the raw R-squared (0.834)
# calculate the root mean squared error (rmse)
resid.glin <- train$y-predict(glin.model)
sqrt(mean(resid.glin^2))

# Comparing linear regression and GAM performance on test data
actual <- test$y
pred.lin <- predict(lin.model, newdata=test)
pred.glin <- predict(glin.model, newdata=test)
resid.lin <- actual-pred.lin
resid.glin <- actual-pred.glin
# Compare the RMSE
sqrt(mean(resid.lin^2))
sqrt(mean(resid.glin^2))
# Compare the R-squared
cor(actual, pred.lin)^2
cor(actual, pred.glin)^2

# Extracting the nonlinear relationships
plot(glin.model)

# Extracting a learned spline from a GAM
sx <- predict(glin.model, type="terms")
summary(sx)
xframe <- cbind(train, sx=sx[,1])
ggplot(xframe, aes(x=x)) + geom_point(aes(y=y), alpha=0.4) + geom_line(aes(y=sx))

