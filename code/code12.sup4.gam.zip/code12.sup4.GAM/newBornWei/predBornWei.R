library(mgcv)
library(ggplot2)

load("NatalBirthData.rData")
train <- sdata[sdata$ORIGRANDGROUP<=5,]
test <- sdata[sdata$ORIGRANDGROUP>5,]

# Build a linear model with four variables.
form.lin <- as.formula("DBWT ~ PWGT + WTGAIN + MAGER + UPREVIS")
linmodel <- lm(form.lin, data=train)
summary(linmodel)

# Build a GAM with the same variables
form.glin <- as.formula("DBWT ~ s(PWGT) + s(WTGAIN) + s(MAGER) + s(UPREVIS)")
glinmodel <- gam(form.glin, data=train)
glinmodel$converged
summary(glinmodel)

# Plotting GAM results
terms <- predict(glinmodel, type="terms")
tframe <- cbind(DBWT = train$DBWT, as.data.frame(terms))
colnames(tframe) <- gsub('[()]', '', colnames(tframe))
pframe <- cbind(tframe, train[,c("PWGT", "WTGAIN", "MAGER", "UPREVIS")])
ggplot(pframe, aes(x=PWGT)) + geom_point(aes(y=scale(sPWGT, scale=F))) + geom_smooth(aes(y=scale(DBWT, scale=F)))

# Checking GAM model performance on hold-out data
pred.lin <- predict(linmodel, newdata=test)
pred.glin <- predict(glinmodel, newdata=test)
# Calculate R-squared
cor(pred.lin, test$DBWT)^2
cor(pred.glin, test$DBWT)^2

# Using GAM for logistic regression
# predict the birth of underweight babies (defined as DBWT < 2000 )
# GLM logistic regression
form <- as.formula("DBWT < 2000 ~ PWGT + WTGAIN + MAGER + UPREVIS")
logmod <- glm(form, data=train, family=binomial(link="logit"))
# GAM logistic regression
form2 <- as.formula("DBWT<2000~s(PWGT)+s(WTGAIN)+s(MAGER)+s(UPREVIS)")
glogmod <- gam(form2, data=train, family=binomial(link="logit"))
glogmod$converged
summary(glogmod)

# measure by ML
