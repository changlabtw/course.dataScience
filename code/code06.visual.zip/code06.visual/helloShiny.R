install.packages("shiny")
library(shiny)
runExample("01_hello")
