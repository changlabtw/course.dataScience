# R IS AN OBJECT-ORIENTED LANGUAGE
class(c(1,2))
##[1] "numeric”

# R IS A FUNCTIONAL LANGUAGE
add <- function(a,b) { a + b}
add(1,2)
## [1] 3 
