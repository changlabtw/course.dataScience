b<-matrix(c(2,4,3,1,5,7), nrow=3,ncol=2)
b[1,2]
##[1] 1
b[2,1]
##[1] 4

#Transpose
t(b)
cbind(b, b)
rbind(b, b)
