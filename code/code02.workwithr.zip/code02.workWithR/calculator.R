1 / 200 * 30
(59 + 73 + 2) / 3 
sin(pi / 2)

# create new objects with <-
x <- 3 * 4