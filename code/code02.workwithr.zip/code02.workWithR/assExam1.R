divide <- function(numerator, denominator) { numerator/denominator }
divide(2,1)
## [1] 2
divide(denominator=2,numerator=1)
## [1] 0.5
divide(denominator<-2,numerator<-1)  # yields 2, a wrong answer
## [1] 2
